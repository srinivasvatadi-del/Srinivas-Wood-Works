// Example: Simple alert for contact form
document.querySelector("form").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Thank you! We will get back to you soon.");
});
